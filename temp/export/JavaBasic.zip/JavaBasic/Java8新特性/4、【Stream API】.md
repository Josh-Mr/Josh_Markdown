##### 一、特点

* Stream API提供了一套新的流式处理的抽象序列；
* Stream API支持函数式编程和链式操作；
* Stream可以表示无限序列，并且大多数情况下是惰性求值的。

##### 二、对比IO的stream

| <br />       | java.io                  | java.util.stream                                                            |
| ---------- | -------------------------- | ----------------------------------------------------------------------------- |
| 存储     | 顺序读写的byte或char     | 顺序输出的任意java对象实例                                                  |
| 存储用途 | 序列化到文件或网络       | 内存计算/业务逻辑                                                           |
| 元素     | 已分配并存储在内存       | 可能未分配，实时计算                                                        |
| 元素用途 | 操作一组已存在的java对象 | **惰性计算** |

* stream惰性计算：**一个stream装换另一个stream时，实际上只存储了转换规则，并没有任何计算发生。调用最后收集数据时才真正的计算。**

* Stream操作步骤

1. **创建 Stream**：一个数据源（如： 集合、数组）， 获取一个流。

2. **中间操作**：一个中间操作链，对数据源的数据进行处理。

3. **终止操作(终端操作)**：一个终止操作，执行中间操作链，并产生结果 。

![](assets/Image-20211222145621-ahdbxqt.png)![]()

##### 三、使用（Collection集合使用）

* **（Iterable 接口方法）forEach**
  ```java
  Map<String ,String> map = new HashMap<>();
  map.put("1","111");
  map.put("2","222");
  map.forEach((a,b)->{
      System.out.print("a="+a);
      System.out.println("b="+b);
  });
  List<Integer> lists = new ArrayList<>();
  for (int i = 0; i < 10; i++) {
      lists.add(i);
  }
  lists.forEach((list) ->{
      if (list == 4){
         return; // 跳出本次循环
      }
  });
  ```

* （stream 接口方法）**forEach**

```java
List<Integer> lists = new ArrayList<>();
lists.stream().forEach(integer -> System.out.println(integer));
```

* （映射返回结果）**map**

```java
List<Integer> collect = lists.stream().map(integer -> integer+1).collect(Collectors.toList()); // 返回加1后的结果
```

* （过滤返回boolean）**filter**
  ```java
  List<Integer> collect1 = lists.stream().filter(integer -> {
      return integer % 2 == 0;
  }).collect(Collectors.toList());
  ```

* （排序）**sorted**
  ```java
  List<Integer> collect2 = lists.stream().sorted((a, b) -> {
      return b.compareTo(a);
  }).collect(Collectors.toList());// 倒排序
  ```

* （收集器）**collect**

1. **收集List**

```java
lists.stream().collect( Collectors.toList() );
```

2. **收集Set**

```java
lists.stream().collect(Collectors.toSet());
```

3. **收集Map**

```java
Mapstring,string map = Stream.of("AA","BB","CC").collect( Collectors.toMap(k->k, v->v+v) );
```

4. **收集后分组（重要）**

```java
Mapinteger collect3 = lists.stream().collect(Collectors.groupingBy(Integer::new));// 当前对象
```

* **在JDK 8中对List按照某个属性分组的代码：getCouponId意思是getCouponId()即是分组主键（格式：类名::方法** **）**

```java
Mapinteger,> resultList = couponList.stream().collect(Collectors.groupingBy(Coupon::getCouponId));
```

5. **count() 返回大小**

6. **Ext**

* 转换操作：map()，filter()，sorted()，distinct()；

* 合并操作：concat()，flatMap()；

* 并行处理：parallel()；

* 聚合操作：reduce()，collect()，count()，max()，min()，sum()，average()；

* 其他操作：allMatch(), anyMatch(), forEach()。
