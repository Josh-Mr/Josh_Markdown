### 一、Lamdba表达式（函数式编程）

#### 1、特征：

* 可选类型声明 - 无需声明参数的类型。编译器可以从该参数的值推断。
* 可选圆括号参数 - 无需在括号中声明参数。对于多个参数，括号是必需的。
* 可选大括号 - 表达式主体没有必要使用大括号，如果主体中含有一个单独的语句。
* 可选return关键字 - 编译器会自动返回值，如果主体有一个表达式返回的值。花括号是必需的，以表明表达式返回一个值。

格式：`parameter -> expression body`

#### 例子：**匿名内部类写法**

```java
new Thread(new Runnable() {
	@Override
	public void run() {
		System.out.println("内部类写法");
	}
}).start();
```

#### **例子：lambda表达式写法**

```java
new Thread(() -> System.out.println("lambda写法")).start();
```

#### 1.形式：入参为空

```java
TestDemo no_param = () -> "hi, no param";
TestDemo no_param2 = () -> { return "hi, no param"; };
System.out.println(no_param.hi());
```

#### 2.**单个参数**

```java
TestDemo2 param = name -> name;
TestDemo2 param2 = name -> { return name;};
 System.out.println(param.hei("hei, grils"));
```

#### 3.多个参数

```java
TestDemo3 multiple = (String hello, String name) -> hello + " " + name;
```

* **一条返回语句，可以省略大括号和return**
  ```java
  TestDemo3 multiple2 = (hello, name) -> hello + name;
  ```

* **多条处理语句，需要大括号和return**

```java
TestDemo3 multiple3 = (hello, name) -> {
	System.out.println("进入内部");
	return hello + name;
};
System.out.println(multiple.greet("hello", "lambda"));
```
