volatile：[https://www.cnblogs.com/paddix/p/5428507.html](https://www.cnblogs.com/paddix/p/5428507.html)

一、Synchronized的作用

* 确保线程互斥的访问同步代码（互斥性）
* 保证共享变量的修改能够及时可见（可见性）
* 有效解决重排序问题
  * 指令重排是指处理器为了提高程序运行效率，可能会对输入代码进行优化，它不保证各个语句的执行顺序同代码中的顺序一致，但是它会保证程序最终执行结果和代码顺序执行的结果是一致的。指令重排序不会影响单个线程的执行，但是会影响到线程并发执行的正确性。

二、Synchronized用法（用Lock接口类也可以实现）

* 代码块
  * 对象-->对象锁
  * Class-->类的Class对象锁
* 普通方法：将该对象上锁
* 静态方法: synchronized方法所在的对象所对应的Class对象

普通方法：

    Java中的每个对象都有一个锁（lock）或者叫做监视器（monitor），当访问某个对象的synchronized方法时，表示将该对象上锁，此时其他任何线程都无法再去访问该synchronized方法了，直到之前的那个线程执行方法完毕后（或者是抛出了异常），那么将该对象的锁释放掉，其他线程才有可能再去访问该synchronized方法。

静态方法：

如果某个synchronized方法是static的，那么当线程访问该方法时，它锁的并不是synchronized方法所在的对象，而是synchronized方法所在的对象所对应的Class对象，因为Java中无论一个类有多少个对象，这些对象会对应唯一一个Class对象，因此当线程分别访问同一个类的两个对象的两个static，synchronized方法时，他们的执行顺序也是顺序的，也就是说一个线程先去执行方法，执行完毕后另一个线程才开始执行。

三、synchronized原理

![](assets/Image(23)-20220110211617-akjvhh3.png)![]()

关于这两条指令的作用，我们直接参考JVM规范中描述：

**monitorenter **

这段话的大概意思为：

每个对象有一个监视器锁（monitor）。当monitor被占用时就会处于锁定状态，线程执行monitorenter指令时尝试获取monitor的所有权，过程如下：

1、如果monitor的进入数为0，则该线程进入monitor，然后将进入数设置为1，该线程即为monitor的所有者。

2、如果线程已经占有该monitor，只是重新进入，则进入monitor的进入数加1.

3.如果其他线程已经占用了monitor，则该线程进入阻塞状态，直到monitor的进入数为0，再重新尝试获取monitor的所有权。

monitorexit：　

这段话的大概意思为：

执行monitorexit的线程必须是objectref所对应的monitor的所有者。

指令执行时，monitor的进入数减1，如果减1后进入数为0，那线程退出monitor，不再是这个monitor的所有者。其他被这个monitor阻塞的线程可以尝试去获取这个 monitor 的所有权。

总结：Synchronized的语义底层是通过一个monitor的对象（进入数）来完成（进入加一、出来减一），其实wait/notify等方法也依赖于monitor对象，这就是为什么只有在同步的块或者方法中才能调用wait/notify等方法。


1. 对象锁
    ```java
    public class FetchMoney {
        public static void main(String[] args) {
            Bank bank = new Bank();//锁这个对象
            Thread t1 = new MoneyThread(bank); // 柜台
            //bank = new Bank();
            Thread t2 = new MoneyThread(bank); // 取款机
            t1.start();
            t2.start();
        }
    }
    class Bank {
        private int money = 1000;
        public synchronized int getMoney(int number) {
            if (number < 0) {
                return -1;
            } else if (number > money) {
                return -2;
            } else if (money < 0) {
                return -3;
            } else {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                money -= number;
                System.out.println("left money: " + money);
                return number;
            }
        }
    }

    class MoneyThread extends Thread {
        private Bank bank;
        public MoneyThread(Bank bank) {
            this.bank = bank;
        }
        @Override
        public void run() {
            System.out.println(bank.getMoney(800));
        }
    }
    ```

2. Class类锁
    ```java
    package com;

    public class ThreadTest4 {
        public static void main(String[] args) {
            Example example = new Example();
            Thread t1 = new TheThread(example);
            example = new Example();
            Thread t2 = new TheThread2(example);
            t1.start();
            t2.start();
        }
    }
    class Example {
        public synchronized static void execute() {
            for (int i = 0; i < 20; i++) {
                try {
                    Thread.sleep((long) (Math.random() * 1000));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("hello: " + i);
            }
        }
        public synchronized static void execute2() {
            for (int i = 0; i < 20; i++) {
                try {
                    Thread.sleep((long) (Math.random() * 1000));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("world: " + i);
            }
        }
    }
    class TheThread extends Thread {
        private Example example;
        public TheThread(Example example) {
            this.example = example;
        }
        @Override
        public void run() {
            this.example.execute();
        }
    }
    class TheThread2 extends Thread {
        private Example example;
        public TheThread2(Example example) {
            this.example = example;
        }
        @Override
        public void run() {
            this.example.execute2();
        }
    }
    ```

3. 代码块类锁或者对象锁
    ```java
    public class ThreadTest5 {
        public static void main(String[] args) {
            Example2 e = new Example2();
            TheThread3 t1 = new TheThread3(e);
            e = new Example2();
            TheThread4 t2 = new TheThread4(e);
            t1.start();
            t2.start();
        }
    }
    class Example2 {
        private Object object = new Object();
        public void execute() {
            synchronized (this)//当前对象锁，如果是Example.class那就是对象锁
            {
                for (int i = 0; i < 20; i++) {
                    try {
                        Thread.sleep((long) (Math.random() * 1000));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("hello: " + i);
                }
            }
        }
        public void execute2() {
            synchronized (this)//当前对象锁
            {
                for (int i = 0; i < 20; i++) {
                    try {
                        Thread.sleep((long) (Math.random() * 1000));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("world: " + i);
                }
            }
        }
    }
    class TheThread3 extends Thread {
        private Example2 example;
        public TheThread3(Example2 example) {
            this.example = example;
        }
        @Override
        public void run() {
            this.example.execute();
        }
    }
    class TheThread4 extends Thread {
        private Example2 example;
        public TheThread4(Example2 example) {
            this.example = example;
        }
        @Override
        public void run() {
            this.example.execute2();
        }
    }
    ```
