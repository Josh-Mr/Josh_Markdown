一、使用场景：

* 提问“在多线程的情况下、如何防止自己的变量被其他线程篡改”?
* 每个线程需要自己单独一份实例（Session可能用到）
* 实例需要被多个方法共享，但不允许被多线程共享
* 场景总结：
  * 使用于每个线程需要自己独立的实例且该实例需要再多个方法中被使用。
  * 也即是变量在线程间隔离而在方法或类间共享的场景。
* 全链路追踪中的 traceId 或者流程引擎中上下文的传递一般采用 ThreadLocal
* Spring 事务管理器采用了 ThreadLocal
* Spring MVC 的 RequestContextHolder 的实现使用了 ThreadLocal

二、ThreadLocal是什么？

* 线程本地变量、提供了线程本地的实例。
* 与普通变量相比、每一个使用该变量（ThreadLocal）的线程都会初始化一个完全独立的实例副本。
* ThreadLocal变量通常被private static 修复，线程结束时，所使用的实例副本都会回收。--内存泄漏？

三、ThreadLocal实现原理

![](assets/Image(26)-20220110212813-vrb9lbl.png)![]()

1、实现原理

* ThreadLocal本地线程变量有一个静态内部类ThreadLocalMap，Map的key就是ThreadLocal的hashcode值，value就是要存的Object值T。
* ThreadLocalMap用来管理一个线程里面有多个ThreadLocal变量。

四、内存泄漏问题 [Java中的内存泄露的几种可能](https://app.yinxiang.com/shard/s57/nl/20268372/05a959b1-5348-4f80-b8e8-6e31258aeae8)

* ThreadLocalMap中使用key为ThreadLocal的弱引用，弱引用的特点是：如果这个对象只存在弱引用，那么这个对象下次垃圾回收就会清理。为什么呢？
* 当ThreadLocalMap的key为弱引用回收ThreadLocal时，由于ThreadLocalMap持有ThreadLocal的弱引用，即使没有手动删除，ThreadLocal也会被回收。
* 当key为null，在下一次ThreadLocalMap调用set(),get()，remove()方法的时候会被清除value值。
