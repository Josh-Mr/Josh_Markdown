一、Thread类的静态方法

* sleep ：线程休眠方法
  * 1、释放了CPU资源 2、不释放锁资源 （外层有synchronized的话）
* yield  : 让出CPU调度
* 1、把当前线程重新回到就绪状态、2、只让其他同等优先级的线程有执行的机会、

二、Thread的对象方法

* wait ：线程等待方法。
  * 1、当前线程暂停执行并释放对象锁和CPU资源、2、让其他线程可以进入同步代码中、当前线程进去对象等待池当中
* notify  & notifyAll ： 唤醒线程方法
* 1、调用方法notify方法后、对象的等待池中移走任意的线程并放到锁同步等待池中、只有锁池才可以获取同步锁、2、如果锁同步等待池中没有线程、notify不起作用的。
* 3、notifyAll、从对象等待池移走所有等待那个对象的线程并放到锁同步等待池中。
* join ：  加入线程方法 
  ```java
  /**
  * @author Josh
  * @version 1.0.0
  * @ClassName JoinThreadDemo.java
  * @Description TODO
  * @createTime 2021-03-16 21:59:00
  */
  public class JoinThreadDemo {
      public static void main(String[] args) {
          Thread thread = new JoinThread01();
          try {
              for(int i = 0 ; i < 5 ; i++) {
                  System.out.println("main = " + i );
                  if (i == 2 ) {
                  thread.start();
                  thread.join();
              }
          }
      } catch (InterruptedException e) {
          e.printStackTrace();
      }
      }
   }
  class JoinThread01 extends Thread{
          @Override
          public void run() {
          for(int i = 0 ; i < 5 ; i++) {
              System.out.println("Join Thread01 = " + i );
          }
      }
  }
  ```
* 一种特殊的wait，当前运行线程调用另一个线程的join方法，当前线程进入阻塞状态直到另一个线程运行结束等待该线程终止。
* 等待调用join方法的线程结束，再继续执行。如：t.join();//主要用于等待t线程运行结束，若无此句，main则会执行完毕，导致结果不可预测。

注意：wait、notify 、notifyall 方法： Synchronized语句块内使用这三个方法
