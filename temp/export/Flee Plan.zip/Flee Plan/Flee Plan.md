mybatis 面试题（精）：

* [https://juejin.im/post/5e1492d9e51d45410d27e9e2](https://juejin.im/post/5e1492d9e51d45410d27e9e2)
* [https://www.cnblogs.com/huajiezh/p/6415388.html](https://www.cnblogs.com/huajiezh/p/6415388.html)

int和Integer区别（面试题）：[https://www.cnblogs.com/guodongdidi/p/6953217.html](https://www.cnblogs.com/guodongdidi/p/6953217.html)
